package Mundo;

public class Libro {
 private String codigo;
 private String titulo;
 private String autor;
 private int aniodepublicacion;
 private double precio;
 private boolean prestado;
 
 
 public Libro(String codigo, String titulo, String autor, int aniodepublicacion, double precio, boolean prestado) {
  super();
  this.codigo = codigo;
  this.titulo = titulo;
  this.autor = autor;
  this.aniodepublicacion = aniodepublicacion;
  this.precio = precio;
  this.prestado = prestado;
 }
    public String getCodigo() { return codigo; }

    public void setCodigo(String codigo) {
        this.codigo = codigo;
        verificarInvariante();
    }

    public String getTitulo() { return titulo; }

    public void setTitulo(String titulo) {
        this.titulo = titulo;
        verificarInvariante();
    }

    public String getAutor() { return autor; }

    public void setAutor(String autor) {
        this.autor = autor;
        verificarInvariante();
    }

    public int getAnioPublicacion() { return aniodepublicacion; }

    public void setAnioPublicacion(int anio) {
        this.aniodepublicacion = anio;
        verificarInvariante();
    }

    public double getPrecio() { return precio; }

    public void setPrecio(double precio) {
        this.precio = precio;
        verificarInvariante();
    }

    public boolean isPrestado() { return prestado; }

    public void setPrestado(boolean prestado) {
        this.prestado = prestado;
        verificarInvariante();
    }

    @Override
    public String toString() {
        return "Libro [codigo=" + codigo + ", titulo=" + titulo +
               ", autor=" + autor + ", anio=" + aniodepublicacion +
               ", precio=" + precio + ", prestado=" + prestado + "]";
    }

    private void verificarInvariante() {
        assert codigo != null && !codigo.isEmpty() : "Codigo invalido";
        assert titulo != null && !titulo.isEmpty() : "Titulo invalido";
        assert autor != null && !autor.isEmpty() : "Autor invalido";
        assert aniodepublicacion > 0 : "Año invalido";
        assert precio >= 0 : "Precio invalido";
    }
}