package Mundo;

import java.util.ArrayList;

/**
 * Gestiona una colección de libros en una biblioteca.
 *
 * <p><b>Invariante de clase:</b></p>
 * <ul>
 *   <li>{@code libros} no es {@code null}.</li>
 * </ul>
 */
public class Biblioteca {

    private ArrayList<Libro> libros;

    public Biblioteca() {
        this.libros = new ArrayList<>();
        verificarInvariante();
    }

    public void agregarLibro(Libro libro) {
        if (libro != null) {
            libros.add(libro);
        }
        verificarInvariante();
    }

    public boolean eliminarLibro(String codigo) {
    	for (int i = 0; i < libros.size(); i++) {
            if (libros.get(i).getCodigo().equals(codigo)) {
                libros.remove(i);
                verificarInvariante();
                return true;
            }
        }
        return false;
    }

    public ArrayList<Libro> getLibros() {
    	return libros;
    }
//Metodo burbuja
    public void ordenarPorTitulo() {
    	int n = libros.size();
        for (int i = 0; i < n - 1; i++) {
            for (int j = 0; j < n - 1 - i; j++) {
                if (libros.get(j).getTitulo().compareToIgnoreCase(libros.get(j + 1).getTitulo()) > 0) {
                    Libro temp = libros.get(j);
                    libros.set(j, libros.get(j + 1));
                    libros.set(j + 1, temp);
                }
            }
        }
        verificarInvariante();
    }

    public void ordenarPorCodigo() {
    	int n = libros.size();
        for (int i = 0; i < n - 1; i++) {
            for (int j = 0; j < n - 1 - i; j++) {
                if (libros.get(j).getCodigo().compareToIgnoreCase(libros.get(j + 1).getCodigo()) > 0) {
                    Libro temp = libros.get(j);
                    libros.set(j, libros.get(j + 1));
                    libros.set(j + 1, temp);
                }
            }
        }
        verificarInvariante();
    }

    public Libro busquedaSecuencial(String titulo) {
    	for (Libro libro : libros) {
            if (libro.getTitulo().equalsIgnoreCase(titulo)) {
                return libro;
            }
        }
        return null;
    }

    public Libro busquedaBinaria(String codigo) {
    	ordenarPorCodigo();
        int inicio = 0;
        int fin = libros.size() - 1;
        while (inicio <= fin) {
            int medio = (inicio + fin) / 2;
            int comparacion = libros.get(medio).getCodigo().compareTo(codigo);
            if (comparacion == 0)return libros.get(medio);
            else if (comparacion < 0) inicio = medio + 1;
            else fin = medio - 1;
        }
        return null;
    }

    private void verificarInvariante() {
        assert libros != null : "La lista de libros no puede ser null";
    }
}