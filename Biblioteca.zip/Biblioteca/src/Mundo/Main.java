package Mundo;

import java.util.Scanner;

/**
 * Clase principal con menú interactivo para gestionar la biblioteca.
 *
 */
public class Main {

    /**
     * Punto de entrada del programa.
     *
     * @param args argumentos de línea de comandos (no utilizados)
     */
    public static void main(String[] args) {
        Biblioteca biblioteca = new Biblioteca();
        Scanner sc = new Scanner(System.in);
        int opcion;

        do {
            System.out.println("\n╔═══════════════════════════════════════╗");
            System.out.println("║      SISTEMA DE BIBLIOTECA            ║");
            System.out.println("╠═══════════════════════════════════════╣");
            System.out.println("║  1. Registrar libro                   ║");
            System.out.println("║  2. Eliminar libro                    ║");
            System.out.println("║  3. Listar libros                     ║");
            System.out.println("║  4. Ordenar por título                ║");
            System.out.println("║  5. Ordenar por código                ║");
            System.out.println("║  6. Búsqueda secuencial (título)      ║");
            System.out.println("║  7. Búsqueda binaria (código)         ║");
            System.out.println("║  0. Salir                             ║");
            System.out.println("╚═══════════════════════════════════════╝");
            System.out.print("Seleccione una opción: ");
            opcion = Integer.parseInt(sc.nextLine());
            sc.nextLine();

            switch (opcion) {
                case 1:
                    System.out.print("Código: ");
                    String codigo = sc.nextLine();
                    System.out.print("Título: ");
                    String titulo = sc.nextLine();
                    System.out.print("Autor: ");
                    String autor = sc.nextLine();
                    System.out.print("Año de publicación: ");
                    int anio = sc.nextInt();
                    System.out.print("Precio: ");
                    double precio = sc.nextDouble();
                    System.out.print("¿Prestado? (true/false): ");
                    boolean prestado = sc.nextBoolean();
                    sc.nextLine();
                    biblioteca.agregarLibro(new Libro(codigo, titulo, autor, anio, precio, prestado));
                    System.out.println("Libro registrado correctamente.");
                    break;

                case 2:
                    System.out.print("Código del libro a eliminar: ");
                    String cod = sc.nextLine();
                    boolean eliminado = biblioteca.eliminarLibro(cod);
                    System.out.println(eliminado ? "Libro eliminado." : "Libro no encontrado.");
                    break;

                case 3:
                    if (biblioteca.getLibros().isEmpty()) {
                        System.out.println("El catálogo está vacío.");
                    } else {
                        for (Libro l : biblioteca.getLibros()) {
                            System.out.println(l);
                        }
                    }
                    break;

                case 4:
                    biblioteca.ordenarPorTitulo();
                    System.out.println("Catálogo ordenado por título.");
                    break;

                case 5:
                    biblioteca.ordenarPorCodigo();
                    System.out.println("Catálogo ordenado por código.");
                    break;

                case 6:
                    System.out.print("Título a buscar: ");
                    String titBuscar = sc.nextLine();
                    Libro encontradoSeq = biblioteca.busquedaSecuencial(titBuscar);
                    System.out.println(encontradoSeq != null ? encontradoSeq : "Libro no encontrado.");
                    break;

                case 7:
                    System.out.print("Código a buscar: ");
                    String codBuscar = sc.nextLine();
                    Libro encontradoBin = biblioteca.busquedaBinaria(codBuscar);
                    System.out.println(encontradoBin != null ? encontradoBin : "Libro no encontrado.");
                    break;

                case 0:
                    System.out.println("Hasta luego.");
                    break;

                default:
                    System.out.println("Opción inválida.");
            }

        } while (opcion != 0);

        sc.close();
    }
}